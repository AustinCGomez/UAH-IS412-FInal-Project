from django.apps import AppConfig


class Is412ProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'is412project'
