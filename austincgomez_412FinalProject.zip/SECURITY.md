# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 0.0.1  | :white_check_mark: |


## Reporting a Vulnerability

Please submit security vulnerbilities to the 'Issues' tab for any that are discovered and the maintainers of the project will attempt to fix them. NOTE: This project is considered to be a 'demo' and not production-proof in this specific fork. 
We recommend that you try and fix the security vulnerbilities in your 'fork' of the project as the project under AustinCGomez will be archieved sometime in December.
