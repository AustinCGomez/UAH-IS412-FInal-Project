# IS 412 Final Project
This Github repository has the entire project creation of my IS 412 final project at The University of Alabama in Huntsville. Everything from the source code of the actual project to the documentation is enclosed in this project. 
## Installation

## Demo
A Demo of the web application in production will be available at the link below: 

On December 12th, 2021, the web application shall be removed from the server and you will need to manually set it up on your local machine to see the product

## License
The source code is made available under the GNU General Public License v3.0. 
The documentation is made available under the Creative Commons License. 
All of the licenses can be found in the appropriate areas of the Github directory. 
